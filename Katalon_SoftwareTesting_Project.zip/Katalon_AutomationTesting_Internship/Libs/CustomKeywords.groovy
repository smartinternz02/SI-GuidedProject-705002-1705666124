
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import com.kms.katalon.core.testobject.TestObject

import java.lang.String



def static "custom_keyword.CheckDropDown.dropDownElement"(
    	TestObject obj	
     , 	String str	) {
    (new custom_keyword.CheckDropDown()).dropDownElement(
        	obj
         , 	str)
}


def static "custom_keyword.Cura_login.greet"() {
    (new custom_keyword.Cura_login()).greet()
}
