<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>section_Appointment Confirmation           _5b3155</name>
   <tag></tag>
   <elementGuidId>af795887-db8f-4bcc-befa-f1af04ec7c51</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#summary</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='summary']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>section</value>
      <webElementGuid>01076076-02e1-4152-a588-3d6ef84f5e38</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>summary</value>
      <webElementGuid>0c5b5206-78c7-4ae2-a0b7-c8f9fa11134f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>section bg-primary</value>
      <webElementGuid>58629417-e146-4229-86e9-4d0048abc540</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    
        
            
                Appointment Confirmation
                Please be informed that your appointment has been booked as following:
                
            
            
                
                    Facility
                
                
                    Hongkong CURA Healthcare Center
                
            
            
                
                    Apply for hospital readmission
                
                
                    Yes
                
            
            
                
                    Healthcare Program
                
                
                    Medicaid
                
            
            
                
                    Visit Date
                
                
                    12/12/2023
                
            
            
                
                    Comment
                
                
                    First appointment
                
            
            
                Go to Homepage
            
        
    
</value>
      <webElementGuid>50ccca12-7677-4301-b42a-488261f87b2a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;summary&quot;)</value>
      <webElementGuid>7bb1a243-aef6-4245-915a-f1f9a0e7f089</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//section[@id='summary']</value>
      <webElementGuid>374e69f6-7474-436d-ba6a-5293215c8dd4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section</value>
      <webElementGuid>7d6435f8-8bd6-4dcd-a3bb-022ffd411c0f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//section[@id = 'summary' and (text() = '
    
        
            
                Appointment Confirmation
                Please be informed that your appointment has been booked as following:
                
            
            
                
                    Facility
                
                
                    Hongkong CURA Healthcare Center
                
            
            
                
                    Apply for hospital readmission
                
                
                    Yes
                
            
            
                
                    Healthcare Program
                
                
                    Medicaid
                
            
            
                
                    Visit Date
                
                
                    12/12/2023
                
            
            
                
                    Comment
                
                
                    First appointment
                
            
            
                Go to Homepage
            
        
    
' or . = '
    
        
            
                Appointment Confirmation
                Please be informed that your appointment has been booked as following:
                
            
            
                
                    Facility
                
                
                    Hongkong CURA Healthcare Center
                
            
            
                
                    Apply for hospital readmission
                
                
                    Yes
                
            
            
                
                    Healthcare Program
                
                
                    Medicaid
                
            
            
                
                    Visit Date
                
                
                    12/12/2023
                
            
            
                
                    Comment
                
                
                    First appointment
                
            
            
                Go to Homepage
            
        
    
')]</value>
      <webElementGuid>50cbded6-4a1d-420d-ac39-9b8798718082</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
